export type Language = 'en' | 'ar';

export const translations = {
  en: {
    // Header
    sultanateOfOman: "Marsad Digital Platform",
    ministryOfEducation: "Marsad Platform",
    unifiedQualityPortal: "Unified Examination Quality Portal",
    contentControl: "Content Control",
    sandboxPrep: "Sandbox Prep",
    sandboxPrepEnv: "Sandbox Prep Environment",
    liveGateway: "Live Gateway",
    liveOfficialGateway: "Live Official Gateway",
    quickRole: "Quick Switch Role (Sandbox)",
    alAzaibaSchool: "Duqm Basic Education School",
    schoolRep: "Duqm School Principal",
    salemAlHarthy: "Salem Al-Harthy",
    subjectSupervisor: "Al Wusta Governorate Auditor",
    khalidAlAmri: "Khalid Al-Amri",
    portalAdmin: "Portal Admin",
    signOut: "Sign Out & Disconnect",
    login: "Log In",
    loginRep: "Portal Representative Login",
    directorLogin: "Director General Login",
    admin: "Admin",
    close: "Close",
    secureConnection: "Secure Connection",
    portalEnvMode: "Portal Environment Mode",
    accCredentials: "Account Credentials",

    // Front/Gateway Page
    welcomeTitle: "Ministry Moderator & Representative Gateway",
    welcomeDesc: "Access point for authorized school representatives to upload exams, and accredited subject supervisors to claim and moderate blueprints.",
    teachersGateway: "Teachers & Moderators Gateway",
    instantSandboxSchool: "Instant School Sandbox Entry",
    instantSandboxMod: "Instant Moderator Sandbox Entry",
    directorGeneralSecretariat: "Director General Secretariat",
    directorGeneralDesc: "Access the administrative oversight portal for national auditing, workload tracking, and regional blueprint metrics.",
    instantSandboxAdmin: "Instant Administrator Entry",
    quickPrefills: "Developer Quick Credentials Info",
    schoolRepDetails: "School Representative Details",
    subjectModSupervisor: "Subject Moderator / Supervisor",
    directorAdmin: "Director General (Admin)",
    orUseStandardPass: "Or Authenticate via standard credentials:",
    emailAddress: "Email Address",
    password: "Password",
    rememberDevice: "Secure and remember this device session",
    authenticateAccess: "Authenticate Access",
    authenticating: "Authenticating Security Profile...",
    notYourDevice: "Sign in with different credentials",

    // Onboarding Form
    finishOnboardTitle: "Complete National Educational Onboarding",
    finishOnboardDesc: "Please verify your academic identity in the Ministry database to authorize your signature credentials.",
    academicRole: "Academic Role Choice",
    fullName: "Full Academic Name (Oman ID Match)",
    schoolNameLabel: "School Representation Name",
    schoolNamePlaceholder: "e.g. Duqm Basic Education School",
    assignedSubject: "Assigned Subject Domain",
    authorizeCaps: "Authorize Representative Capabilities",
    signingUp: "Registering Profile...",

    // General Catalog Views
    nationalCatalog: "National Blueprint Catalog",
    moderationRegistry: "Syllabus Moderation Registry",
    masterAnalytics: "Master Analytics",
    searchPlaceholder: "Search title, target subject, school name...",
    allGrades: "All Grades",
    allSubjects: "All Subjects",
    allStatuses: "All Statuses",
    uploadBtn: "Upload New Assessment",
    noAssessments: "No curriculum assessments match the query.",
    uploadedBy: "Uploaded on {date} by {school}",
    moderatorLabel: "Moderator: {name}",
    noModerator: "Unassigned Queue",
    liveStatsLabel: "National Quality Registry Live Statistics",

    // Overview Stats Widget
    pendingClaim: "Pending Claim",
    inProgressMini: "In Progress",
    totalApproved: "Total Approved",
    revisionRequired: "Revisions Needed",
    claims: "Claims",
    uploads: "Uploads",
    statsOverview: "Overview Statistics",

    // Assessment Forms & Views
    createBlueprint: "Create Exam Blueprint",
    assessmentTitle: "Assessment Title",
    titlePlaceholder: "e.g. End of Semester Math Exam 2026",
    assessmentType: "Assessment Type",
    unifiedExam: "Unified Semester Exam",
    blueprintQuiz: "Syllabus Unit Quiz",
    selectGrade: "Target Grade Level",
    selectSubject: "Syllabus Domain Subject",
    descriptionLabel: "Learning Outcomes & Unit Scope Documentation",
    descPlaceholder: "Describe the curriculum standards, cognitive weighting, and targeted units...",
    questionsPayload: "Constructed Exam Questions (Syllabus Standardized Text)",
    questionsPlaceholder: "Enter the complete draft questions, reading passages, or numeric problems...",
    answersPayload: "Official Marking Scheme / Answers Rubric",
    answersPlaceholder: "Define corresponding marks, expected responses, and grading tolerances...",
    submitToMinistry: "Submit to Ministry of Education Controls",
    submitting: "Submitting Draft...",
    triggerAiPrecheck: "⚡ Run Syllabus AI Quality Pre-Check First",
    cancel: "Cancel",

    // Assessment Detail Card / Pane
    panePlaceholderTitle: "Syllabus Evaluation Viewport",
    panePlaceholderDesc: "Please scroll the national moderation queue and click on any test blueprint to view student questions, answer schemes, verification timelines, and subject review decisions.",
    uploadedOn: "Uploaded on",
    testQuestionsHeader: "Standardized Questions Flow",
    keyAnswerHeader: "Marking Protocol & Expected Rubrics",
    logsTimelineHeader: "Assessment Quality Audit Log History",
    assignedModLabel: "Assigned Moderator",
    claimAssignedReview: "Claim Assigned Review",
    assignedToYou: "Assigned To You",
    byOtherSupervisor: "Claimed by Supervisor",
    publishOfficialDecision: "Publish Official Review Decision",
    modFeedbackPanel: "Moderation Verdict & Educational Feedback",
    revisionRequestComment: "Provide specific revision comments for school representative:",
    feedbackPlaceholder: "State specifically which curriculum indicators require rework, formatting adjustments, or answer rubric clarity changes...",
    approveNoChanges: "Approve - Pass Standard",
    requestRevisions: "Request Revisions (Rework)",

    // Badges / Statuses
    Pending: "Pending Inspection",
    "In Progress": "Under Audit",
    Approved: "Conforming Forms",
    "Revision Request": "Non-conforming Forms",
    "Grade Revision": "Grade Revisions",

    // Admin Dashboard
    nationalQualityAnalytics: "National Quality Analytics Workspace",
    regionalAnalyticsDesc: "Real-time administrative stats regarding teacher examination uploads, regional school matching quotas, and supervisor workflow reviews.",
    reviewCompletion: "Review Completion",
    teacherUploadsTitle: "1. Teacher Uploading Statistics",
    teacherUploadsDesc: "Metrics on syllabus units, quiz assignments, and overall upload composition submitted by faculty.",
    subjectWiseUploads: "Subject-Wise Upload Distribution",
    keyGradeQuotas: "Key Grade-Level Quotas",
    allocatedLevel: "Allocated level",
    noActiveUploads: "No active uploads recorded yet.",
    schoolStatsTitle: "2. Institutional Schools Statistics",
    schoolStatsDesc: "Inspect upload volume and matching status ratio metrics across direct school boundaries in the region.",
    schoolTableInstitution: "School Institution",
    schoolTableTotal: "Total Uploads",
    schoolTableApproved: "Approved",
    schoolTableRevisions: "Revisions",
    schoolTablePending: "Pending",
    schoolTableAppRate: "Approval Rate",
    schoolTableNoPapers: "No papers",
    schoolSelectNote: "Institutional Detail Review:",
    schoolSelectBody: "This institution has loaded {count} total curriculum packets. All papers are automatically mapped under the Oman Unified Portal system to detect any outline deviations before being issued to pedagogical units.",
    supervisorsWorkTitle: "3. Subject Supervisors & Moderators Work Advancement",
    supervisorsWorkDesc: "Track assignments claimed, active moderation status, and review approval velocity metrics across pedagogical reviewers.",
    activeInProgress: "Active In-Progress",
    revisionsMandated: "Revisions Mandated",
    advancementProgress: "Advancement Progress",
    activePapersLeft: "{count} active papers currently incomplete on assigned queue.",
    noGradeMetadata: "No grade metadata uploaded.",
    filterSchoolStats: "Filter school stats...",
    searchSupervisorLogs: "Search supervisor logs...",

    // Languages Names
    english: "English",
    arabic: "العربية",

    // Subjects Translation
    'Arabic Language': 'Arabic Language',
    'English Language': 'English Language',
    'Mathematics': 'Mathematics',
    'Science': 'Science',
    'Physics': 'Physics',
    'Chemistry': 'Chemistry',
    'Biology': 'Biology',
    'Islamic Studies': 'Islamic Studies',
    'Social Studies': 'Social Studies',
    'Information Technology': 'Information Technology',
    'Applied Sciences': 'Applied Sciences',
    'Individual Skills': 'Individual Skills',

    // Grades Translation
    'Grade 1': 'Grade 1',
    'Grade 2': 'Grade 2',
    'Grade 3': 'Grade 3',
    'Grade 4': 'Grade 4',
    'Grade 5': 'Grade 5',
    'Grade 6': 'Grade 6',
    'Grade 7': 'Grade 7',
    'Grade 8': 'Grade 8',
    'Grade 9': 'Grade 9',
    'Grade 10': 'Grade 10',
    'Grade 11': 'Grade 11',
    'Grade 12': 'Grade 12',
    welcomeSealBand: "Sultanate of Oman • Ministry of Education",
    loginSchoolModerator: "Log In as School Representative / Moderator",
    secureZone: "SECURE ZONE",
    adminGateDesc: "Assigned exclusively to Central MOE System Administrators. Lock-guarded area to access superuser overrides, configurations, and logs.",
    adminGateBtn: "Admin Credentials Portal",
    assignedAccountsReference: "Assigned Evaluation Test Accounts Reference",
    schoolRepLabelText: "2. School Representative Details",
    adminLabelText: "1. Portal Admin Account Details",
    supervisorLabelText: "3. Subject Moderator / Supervisor",
    loginGatewayTitle: "Ministry Moderator & Representative Gateway",
    schoolRepHeading: "Representative Login",
    schoolRepSub: "Syllabus and blueprint publisher portal. Upload, revise and draft assessment material.",
    supervisorHeading: "Supervisor / Moderator Login",
    supervisorSub: "Syllabus moderation registry. Review curriculum blueprints, write audit logs, and accredit setup.",
    instantSchoolDesc: "⚡ Instant School Sandbox Entry",
    instantSupervisorDesc: "⚡ Instant Moderator Sandbox Entry",
    adminConsoleHeader: "Administrative Console",
    adminConsoleSub: "This environment is restricted exclusively to authenticated MOE system administrators.",
    ministryAdminCreds: "Ministry Admin Credentials:",
    adminBtn: "Authorize Admin Sign-In",
    instantAdminDesc: "🛡️ Instant Admin Sandbox entry",
    moeOnly: "MOE-ONLY",
    authorizedEmail: "Authorized Email",
    passwordLabel: "Password",
    adminEmail: "Admin Email",
    passcodeLabel: "Security Passcode",
    returnHomeGateway: "← Return to Home Gateway",
    selectRoleDesc: "Select your appropriate role pathway to authorize academic access.",
    discard: "Discard",
    loginAsSupervisorBtn: "Login as Supervisor",
  },
  ar: {
    // Header
    sultanateOfOman: "منصة مرصد الرقمية",
    ministryOfEducation: "منصة مرصد",
    unifiedQualityPortal: "البوابة الموحدة لجودة الامتحانات",
    contentControl: "مراقبة وتحليل المحتوى",
    sandboxPrep: "بيئة تجريبية",
    sandboxPrepEnv: "بيئة التجربة والتحضير",
    liveGateway: "البوابة الرسمية المباشرة",
    liveOfficialGateway: "البوابة الرسمية الفعالة",
    quickRole: "تبديل سريع للمستخدم (بيئة تجريبية)",
    alAzaibaSchool: "مدرسة الدقم للتعليم الأساسي",
    schoolRep: "مدير مدرسة الدقم",
    salemAlHarthy: "سالم الحارثي",
    subjectSupervisor: "مشرف ومدقق محافظة الوسطى",
    khalidAlAmri: "خالد العامري",
    portalAdmin: "رئيس البوابة والأنظمة",
    signOut: "تسجيل الخروج وقطع الاتصال",
    login: "تسجيل دخول",
    loginRep: "دخول ممثلي المدارس والمشرفين",
    directorLogin: "دخول المدير العام والقيادة",
    admin: "الإشراف والتحليل",
    close: "إغلاق",
    secureConnection: "اتصال آمن وموثق",
    portalEnvMode: "نظام تشغيل البوابة",
    accCredentials: "بيانات الاعتماد النشطة",

    // Front/Gateway Page
    welcomeTitle: "بوابة المعلمين والمشرفين التربويين الموحدة",
    welcomeDesc: "المنصة المعتمدة لممثلي المدارس لرفع مسودات الأسئلة، والمشرفين التربويين لاعتماد ومطابقة مواصفات المنهج الدراسي.",
    teachersGateway: "بوابة ممثلي المدارس والمشرفين",
    instantSandboxSchool: "دخول سريع كأنموذج مدرسة (تجريبي)",
    instantSandboxMod: "دخول سريع كأنموذج مشرف (تجريبي)",
    directorGeneralSecretariat: "أمانة ومكتب المدير العام للتقويم",
    directorGeneralDesc: "الوصول إلى لوحة المتابعة الإدارية للتدقيق الوطني، وتوزيع حصص العمل، وإحصائيات التدقيق الإقليمية.",
    instantSandboxAdmin: "دخول سريع كأنموذج مدير عام (تجريبي)",
    quickPrefills: "بيانات الدخول السريع للمطورين",
    schoolRepDetails: "تفاصيل حساب ممثل المدرسة",
    subjectModSupervisor: "حساب المشرف والمقيم التربوي",
    directorAdmin: "المدير العام والتحكم الشامل",
    orUseStandardPass: "أو قم بالدخول باستخدام بيانات المرور الفردية:",
    emailAddress: "البريد الإلكتروني المعتمد",
    password: "كلمة المرور",
    rememberDevice: "توثيق آمن وحفظ جلسة العمل على هذا الجهاز",
    authenticateAccess: "توثيق وتأكيد الدخول",
    authenticating: "جاري التحقق من الهوية التعليمية...",
    notYourDevice: "تسجيل دخول بحساب مغاير",

    // Onboarding Form
    finishOnboardTitle: "استكمال خطوة التوثيق التربوي الوطني",
    finishOnboardDesc: "يرجى تأكيد الهوية الأكاديمية والمهنية في قاعدة بيانات وزارة التعليم لتفعيل التوقيع الرقمي وصلاحيات الرفع.",
    academicRole: "الدور الأكاديمي والمهني",
    fullName: "الاسم الأكاديمي الكامل (مطابق للهوية العمانية)",
    schoolNameLabel: "اسم المؤسسة التعليمية التابع لها",
    schoolNamePlaceholder: "على سبيل المثال: مدرسة الدقم للتعليم الأساسي",
    assignedSubject: "تخصص الإشراف التربوي الرئيسي",
    authorizeCaps: "تأكيد وتخويل الصلاحيات المهنية",
    signingUp: "جاري إنشاء الحساب التربوي الموثق...",

    // General Catalog Views
    nationalCatalog: "الكتالوج الوطني للمواصفات والامتحانات",
    moderationRegistry: "سجل التدقيق والمطابقة التربوية",
    masterAnalytics: "لوحة التحليلات والمتابعة الوطنية",
    searchPlaceholder: "البحث عن العنوان، المادة الدراسية، اسم المدرسة...",
    allGrades: "كل الصفوف الدراسية",
    allSubjects: "كل المواد الدراسية",
    allStatuses: "كل الحالات للطلبات",
    uploadBtn: "رفع مخطط امتحان جديد",
    noAssessments: "لا توجد مخططات تقييم تطابق خيارات البحث الحالية.",
    uploadedBy: "تم الرفع بتاريخ {date} بواسطة {school}",
    moderatorLabel: "المشرف المراجع: {name}",
    noModerator: "في انتظار تعيين مراجع",
    liveStatsLabel: "الإحصائيات المباشرة لسجل الجودة الوطني",

    // Overview Stats Widget
    pendingClaim: "بانتظار تعيين مراجع",
    inProgressMini: "قيد المراجعة الفنية",
    totalApproved: "مجموع المعتمد",
    revisionRequired: "يتطلب تعديلات وإعادة صياغة",
    claims: "الامتحانات الموزعة",
    uploads: "مجموع المرفوع",
    statsOverview: "ملخص الإحصائيات الفورية",

    // Assessment Forms & Views
    createBlueprint: "مسودة مخطط امتحان جديد",
    assessmentTitle: "عنوان المخطط والامتحان",
    titlePlaceholder: "مثاله: امتحان نهاية الفصل ل مادة الرياضيات 2026",
    assessmentType: "نوع مادة التقييم",
    unifiedExam: "امتحان فصلي موحد للمادة",
    blueprintQuiz: "اختبار قصير للوحدات الدراسية",
    selectGrade: "الصف الدراسي المستهدف",
    selectSubject: "ميدان المادة الدراسية",
    descriptionLabel: "مخرجات التعلم المستهدفة ووصف هيكل الامتحان وثقل الوحدات",
    descPlaceholder: "توضيح المؤشرات، معايير التقييم، وتوزيع الأوزان النسبية للأسئلة...",
    questionsPayload: "الأسئلة والمسائل الفنية لورقة الامتحانات",
    questionsPlaceholder: "اكتب هنا صيغة الأسئلة، الفقرات الإنشائية، أو المفردات الامتحانية المقترحة...",
    answersPayload: "نموذج الإجابة الرسمي وآلية توزيع الدرجات",
    answersPlaceholder: "تحديد معايير المصحح، الإجابات المقبولة، وهامش المرونة في التصحيح...",
    submitToMinistry: "إرسال مسودة التقييم لمراجعة وزارة التعليم",
    submitting: "بروتوكول إرسال آمن مسجل...",
    triggerAiPrecheck: "⚡ تشغيل فحص تدقيق المؤشرات بالذكاء الاصطناعي",
    cancel: "إلغاء الأمر",

    // Assessment Detail Card / Pane
    panePlaceholderTitle: "نافذة استعراض وتدقيق المحتوى التعليمي",
    panePlaceholderDesc: "يرجى تصفح طابور الفرز الوطني للتقييم والضغط على أي من المخططات لمراجعة الأسئلة، معايير الإجابة، السجل الزمني، وقرار المشرف التربوي المعتمد.",
    uploadedOn: "تاريخ وساعة الرفع",
    testQuestionsHeader: "استعراض صيغ الأسئلة الفنية",
    keyAnswerHeader: "دليل التصحيح ودرجات الامتحان",
    logsTimelineHeader: "السجل التاريخي لعمليات الجودة وتحركات الملف",
    assignedModLabel: "المشرف التربوي المراجع المسؤول",
    claimAssignedReview: "استلام وتعيين مراجعة الملف لحسابي",
    assignedToYou: "قيد مراجعتك الشخصية",
    byOtherSupervisor: "تم تعيينه لمشرف آخر",
    publishOfficialDecision: "اعتماد ونشر القرار الرسمي لرقابة الجودة",
    modFeedbackPanel: "ملاحظات الفيدباك الأكاديمي والقرار النهائي",
    revisionRequestComment: "ملاحظات وتوجيهات التطوير المطلوبة من المدرسة:",
    feedbackPlaceholder: "أدرج بدقة معايير التدقيق والملحوظات أو الأخطاء اللغوية أو إعادة الصياغة المطلوبة لتسهيل تعديلها من قبل المدرسة...",
    approveNoChanges: "معتمد ومطابق للمواصفات",
    requestRevisions: "يتطلب تعديل وإعادة صياغة (إرجاع للمدرسة)",

    // Badges / Statuses
    Pending: "في انتظار الفحص",
    "In Progress": "تحت التدقيق",
    Approved: "استمارات مطابقة",
    "Revision Request": "استمارات غير مطابقة",
    "Grade Revision": "تعديل درجات",

    // Admin Dashboard
    nationalQualityAnalytics: "مساحة تحليل ومتابعة مؤشرات الجودة الوطنية",
    regionalAnalyticsDesc: "الإحصائيات الإدارية الفورية لمعدل رفع الامتحانات، وتوزيع الحصص الإقليمية للمدارس، ونسب الإنجاز الفني للمشرفين التربويين.",
    reviewCompletion: "نسبة إنجاز فرز وتدقيق الامتحانات",
    teacherUploadsTitle: "1. إحصائيات رفع الملفات من قبل المدرسين",
    teacherUploadsDesc: "توزيع المخططات بين الامتحانات الموحدة والأوراق القصيرة المتركزة حسب المادة.",
    subjectWiseUploads: "التوزيع النسبي للمخططات المرفوعة للمواد الدراسية",
    keyGradeQuotas: "تغطية الصفوف ومطابقة الحصص المقررة",
    allocatedLevel: "الصف المخصص",
    noActiveUploads: "لا توجد طلبات مسجلة حتى الآن.",
    schoolStatsTitle: "2. أداء التغطية والمشاركات للمؤسسات والمدارس",
    schoolStatsDesc: "تتبع حجم الملفات الواردة ونسب الاعتماد والمراجعة لكل مدرسة مشاركة في البوابة الموحدة بالمنطقة.",
    schoolTableInstitution: "المؤسسة التعليمية / المدرسة",
    schoolTableTotal: "مجموع المرفوع",
    schoolTableApproved: "معتمد",
    schoolTableRevisions: "يتطلب تعديل",
    schoolTablePending: "قيد التدقيق والانتظار",
    schoolTableAppRate: "نسبة نجاح الاعتماد الأكاديمي",
    schoolTableNoPapers: "لا يوجد ملفات حالياً",
    schoolSelectNote: "فحص وتدقيق مشاركات المؤسسة الفردية:",
    schoolSelectBody: "قامت مدرسة {count} برفع حزمة فنية متكاملة من الخطط الدراسية والمواصفات. يتم فلترتها آلياً وربطها بالمنهج العماني الوطني للتأكد من مطابقة المخرجات قبل نقلها للتقييم الإشرافي.",
    supervisorsWorkTitle: "3. كفاءة وسرعة تقدم عمل المشرفين التربويين",
    supervisorsWorkDesc: "رصد عمليات الاستلام، الملفات قيد التدقيق لدى كل مراجع، وسرعة إنجاز المراجعة التربوية للمواد.",
    activeInProgress: "تطبيقات قيد التدقيق والتهيئة",
    revisionsMandated: "ملاحظات تعديل مدفوعة للمدارس",
    advancementProgress: "معدل تقدم وإنجاز المراجعات",
    activePapersLeft: "يوجد {count} ملفات غير مكتملة قيد المتابعة والعمل المباشر.",
    noGradeMetadata: "لا يوجد مستندات مخصصة للصفوف والتقييم حالياً.",
    filterSchoolStats: "البحث في إحصائيات المدرسة...",
    searchSupervisorLogs: "استعلام سجل أداء المشرفين...",

    // Languages Names
    english: "English",
    arabic: "العربية",

    // Subjects Translation
    'Arabic Language': 'اللغة العربية',
    'English Language': 'اللغة الإنجليزية',
    'Mathematics': 'الرياضيات',
    'Science': 'العلوم العامة',
    'Physics': 'الفيزياء',
    'Chemistry': 'الكيمياء',
    'Biology': 'الأحياء',
    'Islamic Studies': 'التربية الإسلامية',
    'Social Studies': 'الدراسات الاجتماعية',
    'Information Technology': 'تقنية المعلومات',
    'Applied Sciences': 'العلوم التطبيقية',
    'Individual Skills': 'المهارات الفردية',
    'All Subjects': 'جميع المواد',

    // Grades Translation
    'Grade 1': 'الصف الأول',
    'Grade 2': 'الصف الثاني',
    'Grade 3': 'الصف الثالث',
    'Grade 4': 'الصف الرابع',
    'Grade 5': 'الصف الخامس',
    'Grade 6': 'الصف السادس',
    'Grade 7': 'الصف السابع',
    'Grade 8': 'الصف الثامن',
    'Grade 9': 'الصف التاسع',
    'Grade 10': 'الصف العاشر',
    'Grade 11': 'الصف الحادي عشر',
    'Grade 12': 'الصف الثاني عشر',
    welcomeSealBand: "سلطنة عُمان • وزارة التعليم",
    loginSchoolModerator: "تسجيل الدخول كممثل المدرسة / المشرف المراجع",
    secureZone: "منطقة مراقبة آمنة",
    adminGateDesc: "خاص بمسؤولي النظام ومكتب المدير العام بوزارة التعليم. منطقة محمية للوصول الحصري والتحليلات والتحكم الصارم.",
    adminGateBtn: "بوابة المدير العام وإدارة النظام",
    assignedAccountsReference: "دليل الحسابات التجريبية وبوابات المعاينة السريعة",
    schoolRepLabelText: "2. بيانات حساب ممثل المدرسة (المعلم)",
    adminLabelText: "1. بيانات حساب المدير العام والمشرف الإداري",
    supervisorLabelText: "3. بيانات حساب المشرف التربوي ومقيم المنهج",
    loginGatewayTitle: "بوابة المشرفين وممثلي المدارس المعتمدة",
    schoolRepHeading: "تسجيل دخول ممثل مدرسة",
    schoolRepSub: "بوابة رفع ونشر مواصفات الامتحانات ومراجعة مسودات التقييم المدرسي.",
    supervisorHeading: "تسجيل دخول المشرف التربوي",
    supervisorSub: "بوابتك الرسمية لمراجعة ورقة الامتحان وتقييم مواصفات المنهج وكتابة سجلات التعديل والاعتماد.",
    instantSchoolDesc: "⚡ دخول تجريبي فوري كحساب مدرسة",
    instantSupervisorDesc: "⚡ دخول تجريبي فوري كحساب مشرف مادة",
    adminConsoleHeader: "منصّة التحكم والمتابعة الفنية والإدارية",
    adminConsoleSub: "هذه البيئة التفاعلية مغلقة ومخصصة للمدير العام ومسؤولي النظام بوزارة التعليم للتدقيق الوطني.",
    ministryAdminCreds: "بيانات اعتماد حساب مراجع النظام والمدير العام:",
    adminBtn: "توثيق وتخويل دخول المشرف الإداري",
    instantAdminDesc: "🛡️ دخول تجريبي فوري كحساب مدير عام",
    moeOnly: "إدارة فقط",
    authorizedEmail: "البريد الإلكتروني المعتمد",
    passwordLabel: "كلمة المرور الآمنة",
    adminEmail: "البريد الإلكتروني للإدارة",
    passcodeLabel: "رمز المرور الأكاديمي",
    returnHomeGateway: "← العودة لبوابة الدخول الرئيسية",
    selectRoleDesc: "اختر المسار المخصص لدورك الوظيفي لتأكيد التصريح ببياناتك الأكاديمية.",
    discard: "تجاهل التغيير",
    loginAsSupervisorBtn: "تسجيل الدخول كمشرف مادة",
  }
};

// Helper translation picker function
export function getTranslatedText(key: keyof typeof translations.en, lang: Language): string {
  const dict = translations[lang] || translations.en;
  return (dict[key] as string) || (translations.en[key] as string) || String(key);
}

// Canonical subject definitions with English, Arabic, and synonyms
const SUBJECT_DICTIONARY: Record<string, { en: string; ar: string; aliases: string[] }> = {
  'Arabic Language': {
    en: 'Arabic Language',
    ar: 'اللغة العربية',
    aliases: ['عربي', 'لغة عربية', 'اللغة العربية', 'arabic', 'arabic language']
  },
  'English Language': {
    en: 'English Language',
    ar: 'اللغة الإنجليزية',
    aliases: ['انجليزي', 'لغة إنجليزية', 'لغة انجليزية', 'اللغة الانجليزية', 'english', 'english language']
  },
  'Mathematics': {
    en: 'Mathematics',
    ar: 'الرياضيات',
    aliases: ['رياضيات', 'الرياضيات', 'math', 'maths', 'mathematics']
  },
  'Science': {
    en: 'Science',
    ar: 'العلوم العامة',
    aliases: ['علوم', 'العلوم', 'علوم عامة', 'العلوم العامة', 'general science', 'science']
  },
  'Physics': {
    en: 'Physics',
    ar: 'الفيزياء',
    aliases: ['فيزياء', 'الفيزياء', 'physics']
  },
  'Chemistry': {
    en: 'Chemistry',
    ar: 'الكيمياء',
    aliases: ['كيمياء', 'الكيمياء', 'chemistry']
  },
  'Biology': {
    en: 'Biology',
    ar: 'الأحياء',
    aliases: ['احياء', 'أحياء', 'الأحياء', 'الاحياء', 'biology']
  },
  'Islamic Studies': {
    en: 'Islamic Studies',
    ar: 'التربية الإسلامية',
    aliases: ['اسلامية', 'تربية اسلامية', 'التربية الاسلامية', 'التربية الإسلامية', 'دراسات إسلامية', 'islamic', 'islamic studies']
  },
  'Social Studies': {
    en: 'Social Studies',
    ar: 'الدراسات الاجتماعية',
    aliases: ['دراسات', 'اجتماعيات', 'دراسات اجتماعية', 'الدراسات الاجتماعية', 'social', 'social studies']
  },
  'Information Technology': {
    en: 'Information Technology',
    ar: 'تقنية المعلومات',
    aliases: ['حاسوب', 'تقنية', 'تقنية المعلومات', 'it', 'information technology', 'computer']
  },
  'Applied Sciences': {
    en: 'Applied Sciences',
    ar: 'العلوم التطبيقية',
    aliases: ['علوم تطبيقية', 'العلوم التطبيقية', 'applied sciences']
  },
  'Individual Skills': {
    en: 'Individual Skills',
    ar: 'المهارات الفردية',
    aliases: ['مهارات فردية', 'المهارات الفردية', 'individual skills', 'فنون تشكيلية', 'رياضة مدرسية', 'موسيقى']
  }
};

/**
 * Checks if a subject string denotes a universal/all-subject scope
 */
export function isUniversalSubject(subject?: string | null): boolean {
  if (!subject) return true;
  const s = subject.toLowerCase().trim();
  return (
    s === '' ||
    s === 'all' ||
    s === 'all subjects' ||
    s === 'all_subjects' ||
    s === 'جميع المواد' ||
    s === 'كافة المواد' ||
    s.includes('شامل') ||
    s.includes('كافة') ||
    s.includes('جميع') ||
    s.includes('all subjects')
  );
}

/**
 * Resolves any subject name or synonym to its canonical English key
 */
export function getCanonicalSubject(subjectName?: string | null): string | null {
  if (!subjectName || isUniversalSubject(subjectName)) return null;
  const trimmed = subjectName.trim().toLowerCase();
  
  for (const [canonicalKey, entry] of Object.entries(SUBJECT_DICTIONARY)) {
    if (canonicalKey.toLowerCase() === trimmed) return canonicalKey;
    if (entry.en.toLowerCase() === trimmed) return canonicalKey;
    if (entry.ar.toLowerCase() === trimmed) return canonicalKey;
    if (entry.aliases.some(a => a.toLowerCase() === trimmed)) return canonicalKey;
  }

  // Check partial/contains match for Arabic or English
  for (const [canonicalKey, entry] of Object.entries(SUBJECT_DICTIONARY)) {
    if (trimmed.includes(entry.en.toLowerCase()) || trimmed.includes(entry.ar.toLowerCase())) {
      return canonicalKey;
    }
  }

  return subjectName.trim();
}

/**
 * Determines whether two subjects match (handling Arabic/English synonyms,
 * universal auditor privileges, and multi-disciplinary specialty lists).
 */
export function isSubjectMatch(subjectA?: string | null, subjectB?: string | null): boolean {
  // If either subject is universal or unspecified, they match
  if (isUniversalSubject(subjectA) || isUniversalSubject(subjectB)) {
    return true;
  }
  if (!subjectA || !subjectB) return true;

  const aTrim = subjectA.trim().toLowerCase();
  const bTrim = subjectB.trim().toLowerCase();

  // Direct equality
  if (aTrim === bTrim) return true;

  // Canonical resolution
  const canA = getCanonicalSubject(subjectA);
  const canB = getCanonicalSubject(subjectB);
  if (canA && canB && canA === canB) return true;

  // Normalize common Arabic letters (alif forms, ta marbuta)
  const normAr = (text: string) => 
    text.replace(/[أإآ]/g, 'ا')
        .replace(/ة/g, 'ه')
        .replace(/\s+العامة$/, '')
        .replace(/^ال/, '')
        .trim();

  if (normAr(aTrim) === normAr(bTrim)) return true;

  // Handle multi-subject composite strings (e.g. "Mathematics & Science")
  if (aTrim.includes(bTrim) || bTrim.includes(aTrim)) return true;
  if (canA && bTrim.includes(canA.toLowerCase())) return true;
  if (canB && aTrim.includes(canB.toLowerCase())) return true;

  return false;
}

// Subject converter based on lang
export function translateSubject(subjectName: string, lang: Language): string {
  if (!subjectName || isUniversalSubject(subjectName)) {
    return lang === 'ar' ? 'جميع المواد' : 'All Subjects';
  }
  
  const canonical = getCanonicalSubject(subjectName);
  if (canonical && SUBJECT_DICTIONARY[canonical]) {
    return lang === 'ar' ? SUBJECT_DICTIONARY[canonical].ar : SUBJECT_DICTIONARY[canonical].en;
  }

  const dict = translations[lang];
  if (dict && subjectName in dict) {
    return (dict as any)[subjectName];
  }
  return subjectName;
}

// Grade converter based on lang
export function translateGrade(gradeName: string, lang: Language): string {
  const dict = translations[lang];
  if (dict && gradeName in dict) {
    return (dict as any)[gradeName];
  }
  return gradeName;
}

// Status converter based on lang
export function translateStatus(status: string, lang: Language): string {
  const dict = translations[lang];
  if (dict && status in dict) {
    return (dict as any)[status];
  }
  return status;
}
